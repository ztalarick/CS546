const postData = require("./posts");
const animalData = require("./animals");

module.exports = {
  animal: animalData,
  posts: postData
};
